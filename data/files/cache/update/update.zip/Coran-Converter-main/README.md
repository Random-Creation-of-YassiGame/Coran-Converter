# Coran-Converter
A simple arabic character to number converter, devloped in python with love
